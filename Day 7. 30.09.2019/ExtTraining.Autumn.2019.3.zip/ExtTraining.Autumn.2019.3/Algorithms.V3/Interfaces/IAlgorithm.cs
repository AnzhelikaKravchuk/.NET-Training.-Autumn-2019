﻿namespace Algorithms.V3.Interfaces
{
    public interface IAlgorithm
    {
        int Calculate(int first, int second);
    }
}