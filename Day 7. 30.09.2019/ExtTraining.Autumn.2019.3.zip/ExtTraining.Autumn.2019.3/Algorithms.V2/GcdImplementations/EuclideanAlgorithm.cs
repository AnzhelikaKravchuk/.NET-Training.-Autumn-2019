using Algorithms.V2.Interfaces;

namespace Algorithms.V2.GcdImplementations
{
    public class EuclideanAlgorithm : IAlgorithm
    {
        public int Calculate(int first, int second)
        {
            throw new System.NotImplementedException();
        }
    }
}