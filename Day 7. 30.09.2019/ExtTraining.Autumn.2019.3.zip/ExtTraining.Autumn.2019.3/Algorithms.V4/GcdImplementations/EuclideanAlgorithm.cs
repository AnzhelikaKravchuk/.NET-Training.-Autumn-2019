using Algorithms.V4.Interfaces;

namespace Algorithms.V4.GcdImplementations
{
    public class EuclideanAlgorithm : IAlgorithm
    {
        public int Calculate(int first, int second)
        {
            throw new System.NotImplementedException();
        }
    }
}