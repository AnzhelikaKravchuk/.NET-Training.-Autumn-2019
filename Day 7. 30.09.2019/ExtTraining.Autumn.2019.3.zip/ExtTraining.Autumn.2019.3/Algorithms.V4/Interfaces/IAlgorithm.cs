﻿namespace Algorithms.V4.Interfaces
{
    public interface IAlgorithm
    {
        int Calculate(int first, int second);
    }
}