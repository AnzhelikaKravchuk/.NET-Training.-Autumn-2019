using System.Buffers;
using Algorithms.V4.GcdImplementations;
using Moq;
using Algorithms.V4.Interfaces;
using NUnit.Framework;

namespace Algorithms.V4.Tests
{
    public class GcdTests
    {
        private ILogger _logger;
        private IStopWatcher _stopWatcher ;
        private IAlgorithm _algorithm;

        [OneTimeSetUp]
        public void SetUp()
        {
            _logger = Mock.Of<ILogger>();
            _stopWatcher = Mock.Of<IStopWatcher>();
            _algorithm = Mock.Of<IAlgorithm>();
        }

        [Test]
        public void CalculateDecorator_With_Two_Parameters_And_StopWatcher_And_Logger()
        {
            var gcd = new GCD(_algorithm, _stopWatcher, _logger);
            
            gcd.Calculate(1,3);
            
            Mock<IAlgorithm> mockAlgorithm = Mock.Get(_algorithm);
            mockAlgorithm.Verify(a => a.Calculate(It.IsAny<int>(),It.IsAny<int>()),Times.Once);
            
            Mock<ILogger> mockLogger = Mock.Get(_logger);
            mockLogger.Verify(l => l.Info(It.IsAny<string>()), Times.AtLeastOnce());
            
            Mock<IStopWatcher> mockStopWatcher = Mock<IStopWatcher>.Get(_stopWatcher);
            mockStopWatcher.Verify(sw => !sw.TimeInMilliseconds.Equals(0));
        }

    }
}