using Algorithms.V3.Interfaces;

namespace Algorithms.V3.GcdImplementations
{
    public class EuclideanAlgorithm : IAlgorithm
    {
        public int Calculate(int first, int second)
        {
            throw new System.NotImplementedException();
        }
    }
}