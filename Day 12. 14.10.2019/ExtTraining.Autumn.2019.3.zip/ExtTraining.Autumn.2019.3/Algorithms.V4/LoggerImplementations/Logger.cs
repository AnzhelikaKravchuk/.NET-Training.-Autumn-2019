using Algorithms.V4.Interfaces;
using Microsoft.Extensions.Configuration.Json;
using NLog;
using ILogger = Algorithms.V4.Interfaces.ILogger;

namespace Algorithms.V4.LoggerImplementations
{
    public class Logger : ILogger
    {
        private readonly NLog.Logger logger;

        public Logger()
        {
            LogFactory logFactory =  LogManager.LoadConfiguration("NLog.config.xml");
            logger = logFactory.GetCurrentClassLogger();
        }
        public void Debug(string message)
        {
            logger.Debug(message);
        }

        public void Error(string message)
        {
            logger.Error(message);
        }

        public void Info(string message)
        {
            logger.Info(message);
        }
    }
}