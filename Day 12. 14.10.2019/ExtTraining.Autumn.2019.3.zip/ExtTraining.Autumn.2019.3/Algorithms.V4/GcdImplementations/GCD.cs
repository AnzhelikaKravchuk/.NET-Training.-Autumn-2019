using System;
using Algorithms.V4.Interfaces;

namespace Algorithms.V4.GcdImplementations
{
    /// <summary>
    /// Finds Gcd using various algorithms, processes event logs.
    /// </summary>
    /// <seealso cref="IAlgorithm" />
    public class GCD : IAlgorithm
    {
        private readonly IStopWatcher _sw;
        private readonly IAlgorithm _algorithm;
        private readonly ILogger _logger;

        /// <summary>
        /// Gets the milliseconds.
        /// </summary>
        /// <value>
        /// The milliseconds.
        /// </value>
        public long Milliseconds { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="GCD"/> class.
        /// </summary>
        /// <param name="algorithm">The algorithm.</param>
        /// <param name="stopWatcher">The stop watcher.</param>
        /// <param name="logger">The loger.</param>
        /// <exception cref="System.ArgumentNullException">
        /// The loger is null.
        /// or
        /// The algorithm is null.
        /// or
        /// The stopWatcher is null.
        /// </exception>
        public GCD(IAlgorithm algorithm, IStopWatcher stopWatcher, ILogger logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger), "The logger is null.");

            if (algorithm is null)
            {
                _logger.Error("The algorithm is null.");
                throw new ArgumentNullException(nameof(algorithm), "The algorithm is null.");
            }

            if (stopWatcher is null)
            {
                _logger.Error("The stopWatcher is null.");
                throw new ArgumentNullException(nameof(stopWatcher), "The stopWatcher is null.");
            }

            _algorithm = algorithm;
            _sw = stopWatcher;

            Milliseconds = 0;
        }

        /// <summary>
        /// The method performs calculations for two numbers.
        /// </summary>
        /// <param name="first">The first number.</param>
        /// <param name="second">The second number.</param>
        /// <returns>
        /// GCD.
        /// </returns>
        public int Calculate(int first, int second)
        {
            _sw.Start();
            int result = _algorithm.Calculate(first, second);
            _sw.Stop();

            Milliseconds = _sw.TimeInMilliseconds;

            _logger.Info($"Runtime of a method with two variables: {Milliseconds} milliseconds");
            _logger.Info($"Result solution: {result}");

            return result;
        }

        /// <summary>
        /// Calculates the specified first.
        /// </summary>
        /// <param name="first">The first.</param>
        /// <param name="second">The second.</param>
        /// <param name="third">The third.</param>
        /// <returns>GCD.</returns>
        public int Calculate(int first, int second, int third)
        {
            _sw.Start();
            int result = _algorithm.Calculate(_algorithm.Calculate(first, second), third);
            _sw.Stop();

            Milliseconds = _sw.TimeInMilliseconds;

            _logger.Info($"Runtime of a method with three variables: {Milliseconds} milliseconds");
            _logger.Info($"Result solution: {result}");

            return result;
        }

        /// <summary>
        /// Calculates the specified numbers.
        /// </summary>
        /// <param name="numbers">The numbers.</param>
        /// <returns>GCD.</returns>
        /// <exception cref="System.ArgumentException">To find the GCD, you need at least two numbers.</exception>
        public int Calculate(params int[] numbers)
        {
            if (numbers.Length < 2)
            {
                _logger.Error("To find the GCD, you need at least two numbers.");
                throw new ArgumentException("To find the GCD, you need at least two numbers.");
            }

            _sw.Start();

            int result = _algorithm.Calculate(numbers[0], numbers[1]);
            for (int i = 2; i < numbers.Length; i++)
            {
                result = _algorithm.Calculate(result, numbers[i]);
            }

            _sw.Stop();

            Milliseconds = _sw.TimeInMilliseconds;

            _logger.Info($"Runtime of a method with {numbers.Length} variables: {Milliseconds} milliseconds");
            _logger.Info($"Result solution: {result}");

            return result;
        }
    }
}