using System;
using Algorithms.V4.Interfaces;

namespace Algorithms.V4.GcdImplementations
{
    /// <summary>
    /// Defines a GCD using the Euclidean algorithm.
    /// </summary>
    /// <seealso cref="IAlgorithm" />
    public class EuclideanAlgorithm : IAlgorithm
    {
        /// <summary>
        /// The method performs calculations a GCD using
        /// the Euclidean algorithm.
        /// </summary>
        /// <param name="first">The first number.</param>
        /// <param name="second">The second number.</param>
        /// <returns>
        /// GCD for two numbers.
        /// </returns>
        public int Calculate(int first, int second)
        {
            if (first == 0 || second == 0)
            {
                return 1;
            }

            if (first < 0)
            {
                first = Math.Abs(first);
            }

            if (second < 0)
            {
                second = Math.Abs(second);
            }

            while (first != 0 && second != 0)
            {
                if (first > second)
                {
                    first %= second;
                }
                else
                {
                    second %= first;
                }
            }

            return first + second;
        }
    }
}