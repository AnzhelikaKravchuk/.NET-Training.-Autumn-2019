using System.Diagnostics;
using Algorithms.V4.Interfaces;

namespace Algorithms.V4.StopWatcherImplementations
{
    /// <summary>
    /// StopWatch adapter.
    /// </summary>
    /// <seealso cref="IStopWatcher" />
    public class StopWatcher: IStopWatcher
    {
        private readonly Stopwatch _sw;

        /// <summary>
        /// Initializes a new instance of the <see cref="StopWatcher"/> class.
        /// </summary>
        public StopWatcher()
        {
            TimeInMilliseconds = 0;
            _sw = new Stopwatch();
        }

        /// <summary>
        /// Gets the time in milliseconds.
        /// </summary>
        /// <value>
        /// The time in milliseconds.
        /// </value>
        public long TimeInMilliseconds { get; private set; }

        /// <summary>
        /// Starts this instance.
        /// </summary>
        public void Start()
        {
            _sw.Reset();
            _sw.Start();
        }

        /// <summary>
        /// Stops this instance.
        /// </summary>
        public void Stop()
        {
            TimeInMilliseconds = _sw.ElapsedTicks;
            _sw.Stop();
        }
    }
}