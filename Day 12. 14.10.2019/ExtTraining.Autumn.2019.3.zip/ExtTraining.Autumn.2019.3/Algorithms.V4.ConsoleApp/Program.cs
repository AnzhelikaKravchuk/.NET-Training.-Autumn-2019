﻿using System;
using Algorithms.V4.GcdImplementations;
using Algorithms.V4.Interfaces;
using Algorithms.V4.LoggerImplementations;
using Algorithms.V4.StopWatcherImplementations;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using ILogger = Algorithms.V4.Interfaces.ILogger;

namespace Algorithms.V4.ConsoleApp
{
    static class Program
    {
        static void Main(string[] args)
        {
            var serviceProvider = new ServiceCollection()
                .AddSingleton<ILogger, Logger>()
                .AddSingleton<IStopWatcher, StopWatcher>()
                .AddScoped<IAlgorithm,EuclideanAlgorithm>()
                .BuildServiceProvider();

            IAlgorithm algorithm = serviceProvider.GetService <IAlgorithm>();

            int a = -12, b = 224;
            Console.WriteLine($"GCD({a},{b}) = {algorithm.Calculate(a, b)}.");
            
            ILogger logger = serviceProvider.GetService<ILogger>();
            IStopWatcher stopWatcher = serviceProvider.GetService<IStopWatcher>();
            
            GCD gcdAlgorithm = new GCD(algorithm, stopWatcher, logger);
            int gcd = gcdAlgorithm.Calculate(a, b);
            Console.WriteLine($"GCD({a},{b}) = {gcd} with time = {gcdAlgorithm.Milliseconds}.");
        }
    }
}