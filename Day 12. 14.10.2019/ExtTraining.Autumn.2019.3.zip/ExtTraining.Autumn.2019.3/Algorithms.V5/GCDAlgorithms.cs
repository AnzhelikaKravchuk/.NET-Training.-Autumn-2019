﻿using System;

namespace Algorithms.V5
{
    public static class GCDAlgorithms
    {
        #region GreatestCommonDivisior

        public static int GreatestCommonDivisor(int first, int second)
        {
            throw new NotImplementedException();
        }

        public static int GreatestCommonDivisor(int first, int second, out long elapsedTimeMilliSecs) =>
            CommonDivisor2ParamsWithTime(GreatestCommonDivisor, first, second, out elapsedTimeMilliSecs);

        public static int GreatestCommonDivisor(int first, int second, int third) =>
            CommonDivisor3Params(GreatestCommonDivisor, first, second, third);

        public static int GreatestCommonDivisor(int first, int second, int third, out long elapsedTimeMilliSecs) =>
            CommonDivisor3ParamsWithTime(GreatestCommonDivisor, first, second, third, out elapsedTimeMilliSecs);

        public static int GreatestCommonDivisor(params int[] arrayOfNumbers) =>
            CommonDivisorParams(GreatestCommonDivisor, arrayOfNumbers);

        public static int GreatestCommonDivisor(out long elapsedTimeMilliSecs, params int[] arrayOfNumbers) =>
            CommonDivisorParamsWithTime(out elapsedTimeMilliSecs, GreatestCommonDivisor, arrayOfNumbers);

        #endregion

        #region BinaryGreatestCommonDivisior

        public static int BinaryGreatestCommonDivisor(int first, int second)
        {
            throw new NotImplementedException();
        }

        public static int BinaryGreatestCommonDivisor(int first, int second, out long elapsedTimeMilliSecs) =>
            CommonDivisor2ParamsWithTime(BinaryGreatestCommonDivisor, first, second, out elapsedTimeMilliSecs);

        public static int BinaryGreatestCommonDivisor(int first, int second, int third) =>
            CommonDivisor3Params(BinaryGreatestCommonDivisor, first, second, third);

        public static int
            BinaryGreatestCommonDivisor(int first, int second, int third, out long elapsedTimeMilliSecs) =>
            CommonDivisor3ParamsWithTime(BinaryGreatestCommonDivisor, first, second, third, out elapsedTimeMilliSecs);

        public static int BinaryGreatestCommonDivisor(params int[] arrayOfNumbers) =>
            CommonDivisorParams(BinaryGreatestCommonDivisor, arrayOfNumbers);

        public static int BinaryGreatestCommonDivisor(out long elapsedTimeMilliSecs, params int[] arrayOfNumbers) =>
            CommonDivisorParamsWithTime(out elapsedTimeMilliSecs, BinaryGreatestCommonDivisor, arrayOfNumbers);

        #endregion

        #region Helper methods

        private static int CommonDivisor2ParamsWithTime(Func<int, int, int> gcd, int first, int second,
            out long elapsedTimeMilliSecs)
        {
            throw new NotImplementedException();
        }

        private static int CommonDivisor3Params(Func<int, int, int> gcd, int first, int second, int third) =>
            gcd(gcd(first, second), third);

        private static int CommonDivisor3ParamsWithTime(Func<int, int, int> gcd, int first, int second, int third,
            out long elapsedTimeMilliSecs)
        {
            throw new NotImplementedException();
        }

        private static int CommonDivisorParams(Func<int, int, int> gcd, params int[] arrayOfNumbers)
        {
            throw new NotImplementedException();
        }

        private static int CommonDivisorParamsWithTime(out long elapsedTimeMilliSecs, Func<int, int, int> gcd,
            params int[] arrayOfNumbers)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}