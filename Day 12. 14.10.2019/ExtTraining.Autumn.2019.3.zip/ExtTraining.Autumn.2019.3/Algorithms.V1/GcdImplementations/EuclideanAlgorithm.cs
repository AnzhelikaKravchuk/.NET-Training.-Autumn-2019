using System;
using Algorithms.V1.Interfaces;

namespace Algorithms.V1.GcdImplementations
{
    internal class EuclideanAlgorithm : Algorithm
    {
        protected override int Action(int first, int second)
        {
            throw new NotImplementedException();
        }
    }
}